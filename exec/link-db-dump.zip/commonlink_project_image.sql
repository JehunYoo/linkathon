-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_image`
--

DROP TABLE IF EXISTS `project_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_image` (
  `project_image_id` bigint NOT NULL AUTO_INCREMENT,
  `project_image_name` varchar(200) NOT NULL,
  `project_image_url` varchar(255) NOT NULL,
  `project_origin_image_name` varchar(200) NOT NULL,
  PRIMARY KEY (`project_image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_image`
--

LOCK TABLES `project_image` WRITE;
/*!40000 ALTER TABLE `project_image` DISABLE KEYS */;
INSERT INTO `project_image` VALUES (1,'airfocus.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/airfocus-v89zhr0iBFY-unsplash.jpg','airfocus.jpg'),(2,'alvaro-reyes.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/alvaro-reyes-qWwpHwip31M-unsplash.jpg','alvaro-reyes.jpg'),(3,'amy-hirschi.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/amy-hirschi-izxMVv2Z9dw-unsplash.jpg','amy-hirschi.jpg'),(4,'annie-spratt.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/annie-spratt-dWYU3i-mqEo-unsplash.jpg','annie-spratt.jpg'),(5,'austin-distel.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/austin-distel-_S7-KX8geL0-unsplash.jpg','austin-distel.jpg'),(6,'austin-distel.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/austin-distel-mpN7xjKQ_Ns-unsplash.jpg','austin-distel.jpg'),(7,'austin-distel.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/austin-distel-wD1LRb9OeEo-unsplash.jpg','austin-distel.jpg'),(8,'brands-people.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/brands-people-Ax8IA8GAjVg-unsplash.jpg','brands-people.jpg'),(9,'campaign-creators.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/campaign-creators-e6n7uoEnYbA-unsplash.jpg','campaign-creators.jpg'),(10,'daria-nepriakhina.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/daria-nepriakhina-zoCDWPuiRuA-unsplash.jpg','daria-nepriakhina.jpg'),(11,'eden-constantino.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/eden-constantino-OXmym9cuaEY-unsplash.jpg','eden-constantino.jpg'),(12,'jason-goodman.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/jason-goodman-Oalh2MojUuk-unsplash.jpg','jason-goodman.jpg'),(13,'jason-goodman.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/jason-goodman-vbxyFxlgpjM-unsplash.jpg','jason-goodman.jpg'),(14,'jo-szczepanska.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/jo-szczepanska-5aiRb5f464A-unsplash.jpg','jo-szczepanska.jpg'),(15,'markus-winkler.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/markus-winkler-92HqQ0ZvKDA-unsplash.jpg','markus-winkler.jpg'),(16,'marvin-meyer.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/marvin-meyer-SYTO3xs06fU-unsplash.jpg','marvin-meyer.jpg'),(17,'mimi-thian.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/mimi-thian-vdXMSiX-n6M-unsplash.jpg','mimi-thian.jpg'),(18,'octavian-dan.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/octavian-dan-b21Ty33CqVs-unsplash.jpg','octavian-dan.jpg'),(19,'sebastian-herrmann.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/projectImage/sebastian-herrmann-O2o1hzDA7iE-unsplash.jpg','sebastian-herrmann.jpg'),(20,'static/955bcbe5-b1c9-4b14-aec0-c78bccfb8499alex-perez-uGXEEwnvIkQ-unsplash.webp','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/955bcbe5-b1c9-4b14-aec0-c78bccfb8499alex-perez-uGXEEwnvIkQ-unsplash.webp','alex-perez-uGXEEwnvIkQ-unsplash.webp'),(21,'static/a0af99aa-729a-4d35-805d-d95733dcbe9fali-morshedlou-WMD64tMfc4k-unsplash.webp','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/a0af99aa-729a-4d35-805d-d95733dcbe9fali-morshedlou-WMD64tMfc4k-unsplash.webp','ali-morshedlou-WMD64tMfc4k-unsplash.webp'),(22,'static/dd1cc20c-f2b7-4133-8d9c-6fd2fc923e77allef-vinicius-6ypOmTNK2FA-unsplash.webp','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/dd1cc20c-f2b7-4133-8d9c-6fd2fc923e77allef-vinicius-6ypOmTNK2FA-unsplash.webp','allef-vinicius-6ypOmTNK2FA-unsplash.webp'),(23,'static/c83ef4a1-4c6d-47dd-9861-ae7be6f2bcfabrooke-cagle-86YOjoT3hi4-unsplash.webp','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/c83ef4a1-4c6d-47dd-9861-ae7be6f2bcfabrooke-cagle-86YOjoT3hi4-unsplash.webp','brooke-cagle-86YOjoT3hi4-unsplash.webp'),(24,'static/7189bb59-97d6-4589-a64f-5a8f89b76f4fandrea-rico-yHhtT7-A1Xg-unsplash.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/7189bb59-97d6-4589-a64f-5a8f89b76f4fandrea-rico-yHhtT7-A1Xg-unsplash.jpg','andrea-rico-yHhtT7-A1Xg-unsplash.jpg'),(25,'static/638d9a98-218c-44cf-a133-f4e3a7560914austin-distel-7uoMmzPd2JA-unsplash.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/638d9a98-218c-44cf-a133-f4e3a7560914austin-distel-7uoMmzPd2JA-unsplash.jpg','austin-distel-7uoMmzPd2JA-unsplash.jpg'),(26,'static/6338aff4-e79a-4222-b2d4-554da7d39e12ana-nichita-BI91NrppE38-unsplash.jpg','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/6338aff4-e79a-4222-b2d4-554da7d39e12ana-nichita-BI91NrppE38-unsplash.jpg','ana-nichita-BI91NrppE38-unsplash.jpg'),(54,'static/26e317d1-986f-40b7-810f-c7dca7a3eea6Tensorflow.webp','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/26e317d1-986f-40b7-810f-c7dca7a3eea6Tensorflow.webp','Tensorflow.webp'),(55,'static/d9591d15-6af4-4d43-a5df-5a7fa28eb92aPytorch.webp','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/d9591d15-6af4-4d43-a5df-5a7fa28eb92aPytorch.webp','Pytorch.webp');
/*!40000 ALTER TABLE `project_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:17
