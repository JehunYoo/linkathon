-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hackathon_image`
--

DROP TABLE IF EXISTS `hackathon_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hackathon_image` (
  `hackathon_image_id` bigint NOT NULL AUTO_INCREMENT,
  `hackathon_image_name` varchar(200) NOT NULL,
  `hackathon_image_url` varchar(255) NOT NULL,
  `hackathon_origin_image_name` varchar(200) NOT NULL,
  PRIMARY KEY (`hackathon_image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hackathon_image`
--

LOCK TABLES `hackathon_image` WRITE;
/*!40000 ALTER TABLE `hackathon_image` DISABLE KEYS */;
INSERT INTO `hackathon_image` VALUES (1,'hackathon1','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/ferenc-almasi-c8h0n7fSTqs-unsplash.jpg','origin_hackathon1'),(2,'hackathon2','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/florian-olivo-Ek9Znm8lQ1U-unsplash.jpg\n','origin_hackathon2'),(3,'hackathon3','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/markus-spiske-iar-afB0QQw-unsplash.jpg\n','origin_hackathon3'),(4,'hackathon4','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/nasa-Q1p7bh3SHj8-unsplash.jpg','origin_hackathon4'),(5,'대학생해커톤','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/%EB%8C%80%ED%95%99%EC%83%9D%ED%95%B4%EC%BB%A4%ED%86%A4.webp','대학생해커톤'),(6,'인공지능','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/%EC%9D%B8%EA%B3%B5%EC%A7%80%EB%8A%A5.webp','인공지능'),(7,'직장인 해커톤','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/%EC%A7%81%EC%9E%A5%EC%9D%B8+%ED%95%B4%EC%BB%A4%ED%86%A4.webp','직장인 해커톤'),(8,'핀테크','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/%ED%95%80%ED%85%8C%ED%81%AC.webp','핀테크'),(9,'hackathon5','https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/hackathonImage/d23bf6fd-3033-4155-9ebc-aa61d65e9ef7.webp','hackathon5');
/*!40000 ALTER TABLE `hackathon_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:16
