-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `project_id` bigint NOT NULL AUTO_INCREMENT,
  `deploy_url` varchar(255) DEFAULT NULL,
  `hackathon_score` int NOT NULL,
  `project_desc` varchar(100) DEFAULT NULL,
  `project_name` varchar(30) NOT NULL,
  `project_status` enum('OPENED','CLOSED') NOT NULL,
  `project_url` varchar(255) DEFAULT NULL,
  `registered_date` datetime(6) NOT NULL,
  `win_state` bit(1) NOT NULL,
  `project_image_id` bigint DEFAULT NULL,
  `team_id` bigint NOT NULL,
  PRIMARY KEY (`project_id`),
  UNIQUE KEY `UK_rl2bt06yn51j9nbk2d0tjituy` (`team_id`),
  UNIQUE KEY `UK_j05hmxa7qluwqngqijbwmmd6p` (`project_image_id`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`project_image_id`) REFERENCES `project_image` (`project_image_id`) ON DELETE CASCADE,
  CONSTRAINT `project_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `team` (`team_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,'https://i10a602.p.ssafy.io',76,'AI를 활용한 스마트 홈 개발 프로젝트','Smart Home','CLOSED','https://github.com/woowacourse-teams/2020-seller-lee-company','2024-01-01 00:00:00.000000',_binary '',1,1),(2,'https://i10a602.p.ssafy.io',80,'AI를 활용한 자율주행차 개발 프로젝트','Self-driving','CLOSED','https://github.com/jooyun-1/Quicklog','2024-01-01 00:00:00.000000',_binary '',2,2),(3,'https://example.com',70,'AI를 활용한 헬스케어 서비스 개발 프로젝트','Healthcare','CLOSED','https://github.com','2024-01-01 00:00:00.000000',_binary '',3,3),(4,'https://example.com',85,'CLOUD를 활용한 스마트 팩토리 개발 프로젝트','Smart Factory','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',4,4),(5,'https://example.com',78,'CLOUD를 활용한 스마트 농장 개발 프로젝트','Smart Farm','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',5,5),(6,'https://example.com',67,'CLOUD를 활용한 스마트 시티 개발 프로젝트','Smart City','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',6,6),(7,'https://example.com',72,'CLOUD를 활용한 스마트 그리드 개발 프로젝트','Smart Grid','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',7,7),(8,'https://example.com',83,'CLOUD를 활용한 홈 오토메이션 개발 프로젝트','Home Automation','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',8,8),(9,'https://example.com',80,'CLOUD를 활용한 웨어러블 기기 개발 프로젝트','Wearable','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',9,9),(10,'https://example.com',76,'CLOUD를 활용한 스마트 빌딩 개발 프로젝트','Smart Building','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',10,10),(11,'https://example.com',82,'CLOUD를 활용한 스마트 헬스케어 서비스 개발 프로젝트','Smart Healthcare','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',11,11),(12,'https://example.com',70,'CLOUD를 활용한 스마트 리테일 서비스 개발 프로젝트','Smart Retail','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',12,12),(13,'https://example.com',88,'CLOUD를 활용한 스마트 로지스틱스 서비스 개발 프로젝트','Smart Logistics','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',13,13),(14,'https://example.com',90,'BIG DATA를 활용한 스마트 홈 개발 프로젝트','Smart Home','CLOSED','https://github.com','2024-01-01 00:00:00.000000',_binary '',14,14),(15,'https://example.com',80,'BIG DATA를 활용한 자율주행차 개발 프로젝트','Self-driving','CLOSED','https://github.com','2024-01-01 00:00:00.000000',_binary '',15,15),(16,'https://example.com',70,'BIG DATA를 활용한 헬스케어 서비스 개발 프로젝트','Healthcare','CLOSED','https://github.com','2024-01-01 00:00:00.000000',_binary '',16,16),(17,'https://example.com',85,'BIG DATA를 활용한 스마트 팩토리 개발 프로젝트','Smart Factory','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',17,17),(18,'https://example.com',78,'BIG DATA를 활용한 스마트 농장 개발 프로젝트','Smart Farm','OPENED','https://github.com','2024-02-01 00:00:00.000000',_binary '\0',18,18);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:15
