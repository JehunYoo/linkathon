-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `team_id` bigint NOT NULL AUTO_INCREMENT,
  `team_desc` varchar(100) DEFAULT NULL,
  `team_member` int NOT NULL,
  `team_name` varchar(30) NOT NULL,
  `team_status` enum('BUILDING','COMPLETE') NOT NULL,
  `hackathon_id` bigint NOT NULL,
  PRIMARY KEY (`team_id`),
  KEY `hackathon_id` (`hackathon_id`),
  CONSTRAINT `team_ibfk_1` FOREIGN KEY (`hackathon_id`) REFERENCES `hackathon` (`hackathon_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'AI를 활용한 스마트 홈 개발 팀',4,'Smart Home','COMPLETE',1),(2,'AI를 활용한 자율주행차 개발 팀',4,'Self-driving','COMPLETE',1),(3,'AI를 활용한 헬스케어 서비스 개발 팀',4,'Healthcare','COMPLETE',1),(4,'CLOUD를 활용한 스마트 팩토리 개발 팀',4,'Smart Factory','COMPLETE',2),(5,'CLOUD를 활용한 스마트 농장 개발 팀',4,'Smart Farm','COMPLETE',2),(6,'CLOUD를 활용한 스마트 시티 개발 팀',4,'Smart City','COMPLETE',2),(7,'CLOUD를 활용한 스마트 그리드 개발 팀',4,'Smart Grid','COMPLETE',2),(8,'CLOUD를 활용한 홈 오토메이션 개발 팀',4,'Home Automation','COMPLETE',2),(9,'CLOUD를 활용한 웨어러블 기기 개발 팀',4,'Wearable','COMPLETE',2),(10,'CLOUD를 활용한 스마트 빌딩 개발 팀',4,'Smart Building','COMPLETE',2),(11,'CLOUD를 활용한 스마트 헬스케어 서비스 개발 팀',4,'Smart Healthcare','COMPLETE',2),(12,'CLOUD를 활용한 스마트 리테일 서비스 개발 팀',4,'Smart Retail','COMPLETE',2),(13,'CLOUD를 활용한 스마트 로지스틱스 서비스 개발 팀',4,'Smart Logistics','COMPLETE',2),(14,'AI를 활용한 금융 서비스 개발 팀',1,'Finance Service','BUILDING',3),(15,'AI를 활용한 보안 서비스 개발 팀',1,'Security Service','BUILDING',3),(16,'AI를 활용한 헬스케어 서비스 개발 팀',1,'Healthcare Service','BUILDING',3),(17,'AI를 활용한 물류 서비스 개발 팀',1,'Logistics Service','BUILDING',3),(18,'AI를 활용한 e-Commerce 서비스 개발 팀',1,'e-Commerce Service','BUILDING',3),(117,'1',3,'1','BUILDING',3);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:15
