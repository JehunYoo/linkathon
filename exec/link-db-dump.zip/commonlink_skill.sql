-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skill` (
  `skill_id` bigint NOT NULL AUTO_INCREMENT,
  `skill_image_url` varchar(255) NOT NULL,
  `skill_name` varchar(30) NOT NULL,
  `skill_type` enum('LANGUAGE','FRONTEND','BACKEND','TESTING','DATABASE','DATA','DEVOPS','TOOL','DESIGN') DEFAULT NULL,
  PRIMARY KEY (`skill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` VALUES (1,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/ExpressJS.webp','ExpressJS','BACKEND'),(2,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/Flask.webp','Flask','BACKEND'),(3,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/Hibernate.webp','Hibernate','BACKEND'),(4,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/NestJS.webp','NestJS','BACKEND'),(5,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/NodeJS.webp','NodeJS','BACKEND'),(6,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/RabbitMQ.webp','RabbitMQ','BACKEND'),(8,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/SpringBoot.webp','SpringBoot','BACKEND'),(9,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/backend/WebRTC.webp','WebRTC','BACKEND'),(10,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Airflow.webp','Airflow','DATA'),(11,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Grafana.webp','Grafana','DATA'),(12,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/HBase.webp','HBase','DATA'),(13,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Hadoop.webp','Hadoop','DATA'),(14,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Kafka.webp','Kafka','DATA'),(15,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Prometheus.webp','Prometheus','DATA'),(16,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Tensorflow.webp','Tensorflow','DATA'),(17,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/data/Zeppelin.webp','Zeppelin','DATA'),(18,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/database/ElasticSearch.webp','ElasticSearch','DATABASE'),(19,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/database/MongoDB.webp','MongoDB','DATABASE'),(20,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/database/MySQL.webp','MySQL','DATABASE'),(21,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/database/Redis.webp','Redis','DATABASE'),(22,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/devops/Docker.webp','Docker','DEVOPS'),(23,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/devops/Github Action.webp','Github Action','DEVOPS'),(24,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/devops/Jenkins.webp','Jenkins','DEVOPS'),(25,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/devops/Kubernetes.webp','Kubernetes','DEVOPS'),(26,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/Angular.webp','Angular','FRONTEND'),(27,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/GraphQL.webp','GraphQL','FRONTEND'),(28,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/NextJS.webp','NextJS','FRONTEND'),(29,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/ReactJS.webp','ReactJS','FRONTEND'),(30,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/Redux.webp','Redux','FRONTEND'),(31,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/Styled-Components.webp','Styled-Components','FRONTEND'),(32,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/frontend/VueJS.webp','VueJS','FRONTEND'),(33,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/C%2B%2B.webp','C++','LANGUAGE'),(34,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Go.webp','Go','LANGUAGE'),(35,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Java.webp','Java','LANGUAGE'),(36,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Javascript.webp','Javascript','LANGUAGE'),(37,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Kotlin.webp','Kotlin','LANGUAGE'),(38,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Python.webp','Python','LANGUAGE'),(39,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Swift.webp','Swift','LANGUAGE'),(40,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/language/Typescript.webp','Typescript','LANGUAGE'),(41,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/teamTool/Confluence.webp','Confluence','TOOL'),(42,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/teamTool/Jira.webp','Jira','TOOL'),(43,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/teamTool/Slack.webp','Slack','TOOL'),(44,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/testingTool/JUnit.webp','JUnit','TESTING'),(45,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/testingTool/Jest.webp','Jest','TESTING'),(46,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/testingTool/Mocha.webp','Mocha','TESTING'),(47,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/testingTool/Puppeteer.webp','Puppeteer','TESTING'),(48,'https://a602-link-bucket-jm.s3.ap-northeast-2.amazonaws.com/static/skillImage/testingTool/Selenium.webp','Selenium','TESTING');
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:11
