-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_like`
--

DROP TABLE IF EXISTS `project_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_like` (
  `like_id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`like_id`),
  KEY `user_id` (`user_id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `project_like_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `project_like_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_like`
--

LOCK TABLES `project_like` WRITE;
/*!40000 ALTER TABLE `project_like` DISABLE KEYS */;
INSERT INTO `project_like` VALUES (34,7,53),(35,11,87),(36,2,17),(37,10,75),(38,9,16),(39,12,69),(40,2,66),(41,6,34),(42,10,74),(43,6,92),(44,6,24),(45,3,72),(46,6,66),(47,12,22),(48,10,83),(49,1,48),(50,2,89),(51,9,10),(52,1,62),(53,3,68),(54,10,67),(55,7,13),(56,10,66),(57,12,97),(58,10,97),(59,6,65),(60,13,101),(61,12,49),(62,6,15),(63,6,62),(64,8,48),(65,12,33),(66,5,7),(67,12,80),(68,13,7),(69,12,46),(70,10,2),(71,4,59),(72,10,42),(73,7,83),(74,6,16),(75,7,58),(76,13,77),(77,12,84),(78,6,31),(79,6,56),(80,6,69),(81,1,39),(82,7,93),(83,9,6),(84,13,100),(85,9,54),(86,3,53),(87,7,74),(88,3,93),(89,11,14),(90,11,8),(91,4,99),(92,8,56),(93,11,30),(94,8,9),(95,1,85),(96,1,84),(97,11,31),(98,8,11),(99,6,28),(100,10,6),(101,6,63),(102,6,79),(103,5,62),(104,10,92),(105,7,79),(106,11,45),(107,5,68),(108,11,68),(109,8,26),(110,8,47),(111,1,82),(112,6,96),(113,1,23),(114,11,92),(115,10,72),(116,4,71),(117,3,48),(118,4,44),(119,6,83),(120,4,40),(121,8,101),(122,13,79),(123,5,66),(124,11,90),(125,5,58),(126,11,98),(127,12,7),(128,8,15),(129,6,97),(130,10,31),(131,3,8),(132,5,54),(133,10,28),(134,9,47),(135,6,73),(136,2,90),(137,12,24),(138,12,18),(139,13,65),(140,11,66),(141,6,46),(142,7,41),(143,4,48),(144,9,76),(145,3,96),(146,12,45),(147,1,43),(148,1,40),(149,12,87),(150,3,69),(151,2,44),(152,5,72),(153,4,61),(154,8,53),(155,5,2),(156,13,44),(157,6,2),(158,6,85),(159,6,37),(160,10,17),(161,1,63),(162,1,1),(163,2,1),(166,14,1020),(167,3,1018);
/*!40000 ALTER TABLE `project_like` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:10
