-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10a602.p.ssafy.io    Database: commonlink
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hackathon`
--

DROP TABLE IF EXISTS `hackathon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hackathon` (
  `hackathon_id` bigint NOT NULL AUTO_INCREMENT,
  `end_date` date NOT NULL,
  `hackathon_name` varchar(100) NOT NULL,
  `hackathon_topic` varchar(30) NOT NULL,
  `max_point` int NOT NULL,
  `max_team_member` int NOT NULL,
  `register_date` date NOT NULL,
  `start_date` date NOT NULL,
  `team_deadline_date` date NOT NULL,
  `hackathon_image_id` bigint DEFAULT NULL,
  PRIMARY KEY (`hackathon_id`),
  UNIQUE KEY `UK_jpbvc88sdpp0hpoa2ytddac5b` (`hackathon_image_id`),
  CONSTRAINT `FKonnmfj7g3cddug22nqarnk2ou` FOREIGN KEY (`hackathon_image_id`) REFERENCES `hackathon_image` (`hackathon_image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hackathon`
--

LOCK TABLES `hackathon` WRITE;
/*!40000 ALTER TABLE `hackathon` DISABLE KEYS */;
INSERT INTO `hackathon` VALUES (1,'2024-01-15','자연어 처리를 활용한 챗봇 개발','AI',30,4,'2024-01-01','2024-01-10','2024-01-05',1),(2,'2024-02-20','클라우드 기반 스마트 시티 솔루션 개발','CLOUD',30,4,'2024-02-01','2024-02-10','2024-02-05',2),(3,'2024-03-15','AI를 이용한 페이크 뉴스 및 사이버 딥페이크 탐지 웹 개발','AI',30,4,'2024-02-14','2024-03-10','2024-03-05',3),(4,'2024-04-15','글로벌 스마트 시티 개발','IoT',30,4,'2024-02-14','2024-04-10','2024-04-05',4),(5,'2024-05-15','대학생 굼융 빅데이터 서비스 개발','Big Data',30,4,'2024-02-14','2024-05-10','2024-05-05',5),(6,'2024-06-15','개인 금융 관리 앱/웹 개발','FinTech',30,4,'2024-02-14','2024-06-10','2024-06-05',6);
/*!40000 ALTER TABLE `hackathon` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:30:14
